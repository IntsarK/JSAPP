alert('Hello world');

let favoriteFood = 'Fries';
document.write(favoriteFood);